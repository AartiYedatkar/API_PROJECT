package com.kiranacademy.restapi.restapiex;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@CrossOrigin("http://localhost:8081")
public class StudentController {
    
	
	ArrayList<Student> arraylist= new ArrayList();
  
	
	StudentController(){
		 
		Student student1 = new Student (1,90);
		Student student2 = new Student (2,80);
		
		arraylist.add(student1);
		arraylist.add(student2);
	}
	
	@GetMapping("student")
	ArrayList allStudents() {
		 
		return arraylist;
	}
	@GetMapping("student/{rno}")
	public Student getstudent (@PathVariable int rno) {
		
		for (Student student : arraylist) {
			
			if (student.rno==rno) {
				
				return student;
			}
		}     return null;
	}	
		
	@PostMapping("student")
		public ArrayList addstudent(@RequestBody Student student){
		 
		  arraylist.add(student);
			
			return arraylist;
		}
	
	
	@PutMapping("student")
	public ArrayList updatestudent(@RequestBody Student Clientstudent) {
		
		Student updatestudent=null;
		
		for (Student student : arraylist) {
			
			if (student.rno==Clientstudent.rno) {
				updatestudent=student;
			}
			
		} updatestudent.setMarks(Clientstudent.getMarks());
		
		
		return arraylist;
	}
	
	//we can get concurrent  modification exception
	/*public ArrayList updatestudent(@RequestBody Student ClientStudent) {
		for (Student student : arraylist) {
			
			if (student.rno ==ClientStudent.rno) {
				
				student.setMarks(ClientStudent.getMarks());
			}
		}
		
		return arraylist;
	}*/
	
	//this code can occur concurrent modificstion exception
	
	/*@DeleteMapping("student/{rno}")
	public String deletestudent(@PathVariable int rno ) {
		
		for (Student student : arraylist) {
			
			if(student.rno==rno) {
				
			arraylist.remove(student);
		}
		
}
		return"record deleted";
	}*/
	@DeleteMapping("student/{rno}")
 public String deletestudent(@PathVariable int rno) {
	 Student deleteStudent=null;
	 
		for (Student student : arraylist) {
			if (student.rno==rno) {
				deleteStudent=student;
			break;
			}
			
		} arraylist.remove(deleteStudent);
		
		return "record got deleted";
 }
}
	

